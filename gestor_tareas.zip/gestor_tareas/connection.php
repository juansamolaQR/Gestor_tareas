<?php
        $conexion = mysqli_connect('127.0.0.1:3307','root','','tareas');
        if ($conexion) {
    
         echo 'todo piola pa';
    
        };
?>