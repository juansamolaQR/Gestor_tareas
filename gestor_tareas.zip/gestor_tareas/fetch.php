<?php
include('connection.php');

$getquery = "SELECT * FROM `tareas`";

$resultadoget = mysqli_query($conexion,$getquery);

while($row=mysqli_fetch_array($resultadoget))
    {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['tarea'] . "</td>";
        if($row['estado'] == 0){
            $estado = "Pendiente";
        } else {
            $estado = "Completado";
        }
        echo "<td>" . $estado . "</td>";
        echo "<td>" . $row['fechayhora'] . "</td>";
        echo '<td><button class="btn btn-danger" id="delete" onclick="myDelete('.$row['id'].')"> Delete </button> <button class="btn btn-success" id="finish" onclick="myModify('.$row['id'].')"> Finished </button></td>'; 
        echo "</tr>";
    }
    echo '</table>';
?>