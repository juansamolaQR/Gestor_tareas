document.getElementById("subir").addEventListener("click", function () {
  var inputValor = document.getElementById('task').value;
    const data = {
      input: inputValor
    };
    
    $.ajax({
      type: "POST",
      url: "tasks.php",
      data: data,
      success: function(response){
        //location.href = "tasks.php";
        Swal.fire({
          title: "Se subio la tarea:" +" "+ inputValor,
          confirmButtonText: "OK",
        }).then((result) => {
          if (result.isConfirmed) {
            location.reload();
          }
        });
}})
    
    })
    $(document).ready( function () {
      $.ajax({
        url     : 'fetch.php',
        data    : {},
        type    : 'GET',
        success : function(resp){
            $("#tablebody").html(resp);
        },
        error   : function(resp){
            //alert(JSON.stringify(resp));  open it to alert the error if you want
        }  
    });
    
    });

    function myDelete(deleteid){
      Swal.fire({
        title: "¿Estas seguro de eliminar esta tarea?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Eliminar",
        denyButtonText: `No eliminar`
      }).then((result) => {
        if (result.isConfirmed) {
          $.ajax({
            type:"post",
            url:"delete.php",
            data: { delete : deleteid},
            success:function(data){
              location.reload();
              Swal.fire("¡Eliminado!", "", "success");
            }
        });
        } else if (result.isDenied) {
          Swal.fire("No se elimino la tarea", "", "info");
        }
      });
    }


    function myModify(modifyid){
      Swal.fire({
        title: "¿Estas seguro de completar esta tarea?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Completar",
        denyButtonText: `No completar`
      }).then((result) => {
        if (result.isConfirmed) {
          $.ajax({
            type:"post",
            url:"modify.php",
            data: { modify : modifyid},
            success:function(data){
              location.reload();
              Swal.fire("¡Completado!", "", "success");
            }
        });
        } else if (result.isDenied) {
          Swal.fire("No completado", "", "info");
        }
      });
    }