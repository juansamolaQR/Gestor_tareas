<?php
include('connection.php');

$data = $_POST['modify'];

$modify = "UPDATE `tareas` SET `estado`= 1 WHERE id = $data";

$resultadoModify = mysqli_query($conexion,$modify);

?>