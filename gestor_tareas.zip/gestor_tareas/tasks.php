<?php
include('connection.php');

$data = $_POST['input'];

$insert = "INSERT INTO `tareas`(`id`, `tarea`, `estado`) VALUES ('', '$data' , 0)";

$resultadoInsert = mysqli_query($conexion,$insert);

?>