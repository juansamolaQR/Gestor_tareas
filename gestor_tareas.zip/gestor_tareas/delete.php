<?php
include('connection.php');

$data = $_POST['delete'];

$delete = "DELETE FROM `tareas` WHERE id=$data";

$resultadoDelete = mysqli_query($conexion,$delete);

?>